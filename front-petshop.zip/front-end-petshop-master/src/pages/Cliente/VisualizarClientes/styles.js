import styled from "styled-components";

export const ButtonPosition = styled.div`
  display: inline-block;
  position: relative;
  top: 20px;
  margin-left: 200px;
`;

export const BuscaPosition = styled.div`
  display: inline-block;
  position: relative;
  margin-left: 100px;
`;
